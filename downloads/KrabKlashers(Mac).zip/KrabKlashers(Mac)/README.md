Krab Klashers
=============
Controls:

-WASD movement

-Space to jump

-Left click to basic attack

-Right click to dash attack

-Left shift to check scoreboard
